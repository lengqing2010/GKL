﻿Imports System.IO.Ports

Public Class Form1

    Dim WithEvents RS232 As SerialPort
    Delegate Sub SetTextCallback(ByVal InputString As String)       '声明一个代理

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        For Each sp As String In SerialPort.GetPortNames()
            cmbCom.Items.Add(sp)
        Next
        cmbCom.Sorted = True
        cmbCom.SelectedIndex = 0
    End Sub

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        Dim mBaudRate As Integer
        Dim mParity As IO.Ports.Parity
        Dim mDataBit As Integer
        Dim mStopBit As IO.Ports.StopBits
        Dim mPortName As String

        mPortName = cmbCom.SelectedItem.ToString
        mBaudRate = 9600
        mParity = Parity.None
        mDataBit = 8
        mStopBit = StopBits.One

        RS232 = New IO.Ports.SerialPort(mPortName, mBaudRate, mParity, mDataBit, mStopBit)

        If Not RS232.IsOpen Then
            RS232.Open()
            btnSend.Enabled = True
            RS232.ReceivedBytesThreshold = 1        '设置引发事件的门限值
        Else
            MsgBox("通讯端口打开错误！", MsgBoxStyle.Critical)
        End If
    End Sub


    Private Sub RS232_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles RS232.DataReceived
        Dim InByte() As Byte, ReadCount As Integer, strRead As String
        If RS232.BytesToRead <= 0 Then Exit Sub
        ReDim InByte(RS232.BytesToRead - 1)
        ReadCount = RS232.Read(InByte, 0, RS232.BytesToRead)
        strRead = ""
        If ReadCount = 0 Then
            Exit Sub
        Else
            For Each bData As Byte In InByte
                strRead += bData.ToString & vbCrLf     '若有数据则加到接收文本框
                DisplayText(strRead)
            Next
        End If


    End Sub
    '*************************************************
    '代理子程序
    '处理上述通信端口的接收事件
    '由于欲将数据显示到接收文本框中，因此必须检查
    '是否由另外得Thread所调用的，若是，则必须先
    '建立代理对象
    'Invoke用于在拥有控件基础窗口控制代码的线程上
    '运行代理
    '*************************************************
    Private Sub DisplayText(ByVal comData As String)
        '如果调用txtReceive的另外的线程，返回true
        If Me.txtReceive.InvokeRequired Then
            '利用代理类型建立对象，并指定代理的函数
            Dim d As New SetTextCallback(AddressOf DisplayText)
            Me.Invoke(d, New Object() {comData})    '以指定的自变量列表调用函数
        Else '相同的线程
            'showstring(comData)     '将收到的数据填入接收文本框中
            Me.txtReceive.Text += comData
        End If
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        If RS232 Is Nothing OrElse Not RS232.IsOpen Then   '尚未打开
            MsgBox("通讯端口尚未打开", MsgBoxStyle.Critical Or MsgBoxStyle.OkCancel)
        Else
            RS232.Close()
            btnStart.Enabled = False
            btnClose.Enabled = False
            RS232 = Nothing
        End If
    End Sub

    Private Sub btnEnd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEnd.Click
        If Not RS232 Is Nothing Then
            If RS232.IsOpen Then RS232.Close()
        End If
        End
    End Sub

    Private Sub btnSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSend.Click
        Dim bDataOut(0) As Byte
        Try
            bDataOut(0) = CType(Me.txtSend.Text, Byte)        '将类型转换为字节
            RS232.Write(bDataOut, 0, 1)
        Catch ex As Exception
            MessageBox.Show("输入数值错误：" + ex.ToString, "错误通知：", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Private Sub cmbCom_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbCom.KeyPress
        e.KeyChar = ChrW(0)             '禁止用户在其中输入任何文字
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Hide()
        Form2.Show()
    End Sub
End Class
