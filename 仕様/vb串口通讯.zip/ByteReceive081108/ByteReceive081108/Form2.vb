﻿'**************************************************************
'时间：2008-11-08
'作者：lincyang
'实际应用中，串行通信的数据可能一次发送大量的数据，
'发送之前就必须将数据先编码，
'将其编成我们需要的字节数组数据，
'才能将这些数据以字节的方式发送出去
'目前操作系统使用的字符数据是Unicode：所有的字符均使用
'两个字节来表示一个字符
'**************************************************************

Imports System.IO.Ports
Imports System.Text
Public Class Form2
    Dim RS232 As SerialPort
    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        For Each sp As String In SerialPort.GetPortNames()
            cmbCom.Items.Add(sp)
        Next
        cmbCom.Sorted = True
        cmbCom.SelectedIndex = 0
    End Sub

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        Dim mBaudRate As Integer
        Dim mParity As IO.Ports.Parity
        Dim mDataBit As Integer
        Dim mStopBit As IO.Ports.StopBits
        Dim mPortName As String

        mPortName = cmbCom.SelectedItem.ToString
        mBaudRate = 9600
        mParity = Parity.None
        mDataBit = 8
        mStopBit = StopBits.One

        RS232 = New IO.Ports.SerialPort(mPortName, mBaudRate, mParity, mDataBit, mStopBit)

        If Not RS232.IsOpen Then
            RS232.Open()
            btnSend.Enabled = True
            Timer1.Interval = 100
            Timer1.Enabled = True
        Else
            MsgBox("通讯端口打开错误！", MsgBoxStyle.Critical)
        End If
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim InByte() As Byte, ReadCount As Integer
        If RS232.BytesToRead <= 0 Then Exit Sub
        ReDim InByte(RS232.BytesToRead - 1)
        ReadCount = RS232.Read(InByte, 0, RS232.BytesToRead)

        If ReadCount = 0 Then
            Exit Sub
        Else
            For Each bData As Byte In InByte
                Me.txtReceive.Text += bData.ToString & vbCrLf     '若有数据则加到接收文本框

            Next
        End If
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        If RS232 Is Nothing OrElse Not RS232.IsOpen Then   '尚未打开
            MsgBox("通讯端口尚未打开", MsgBoxStyle.Critical Or MsgBoxStyle.OkCancel)
        Else
            RS232.Close()
            btnStart.Enabled = False
            btnClose.Enabled = False
            Timer1.Enabled = False
            RS232 = Nothing
        End If
    End Sub

    Private Sub btnSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSend.Click
        Dim bDataOut() As Byte, Buf As String
        Dim iSentCount As Integer
        Dim Encode1 As Encoding = Encoding.ASCII         '声明编码对象，使用ASCII

        Try
            Buf = txtSend.Text.Trim()
            bDataOut = Encode1.GetBytes(Buf)      '将字符串转换为字节数组
            iSentCount = bDataOut.GetLength(0)     '发送总字节数
            '显示出总字节数
            lblSentCount.Text = "总传输量：" & iSentCount.ToString & "字节"
            RS232.Write(bDataOut, 0, iSentCount)
        Catch ex As Exception
            MessageBox.Show("输入数值错误：" + ex.ToString, "错误通知", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Private Sub btnEnd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEnd.Click
        If Not RS232 Is Nothing Then
            If RS232.IsOpen Then RS232.Close()
        End If
        End
    End Sub

    Private Sub cmbCom_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbCom.KeyPress
        e.KeyChar = ChrW(0)             '禁止用户在其中输入任何文字
    End Sub
End Class